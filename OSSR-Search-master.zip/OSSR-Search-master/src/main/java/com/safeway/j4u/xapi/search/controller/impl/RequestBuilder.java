package com.safeway.j4u.xapi.search.controller.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import com.safeway.j4u.xapi.search.controller.params.ParamsImpl;

public class RequestBuilder {

  private RequestBuilder() {}

  // Builds a hashmap to avoid concurrentModificationException
  public static Map<String, String> buildmap(Map<String, String> id, String aisle) {
    HashMap<String, String> result = new HashMap<>();
    for (Entry<String, String> e : id.entrySet()) {
      String s = e.getKey();
      result.put(s, id.get(s));
    }
    result.put(ParamsImpl.AISLE, aisle);
    return result;
  }

}
