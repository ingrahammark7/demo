package com.safeway.j4u.xapi.search.datamodel.elevaate;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class ElevaateObject {

  public static final String FEATURED = "FeaturedProduct";
  public static final String FALS = "false";
  public static final String TRU = "true";
  public static final String PRODUCTIDINFEED = "productIdInFeed";
  public static final String PRODUCTATTRIBUTES = "productAttributes";
  public static final String UPC = "UPC";
  public static final String TITLE = "title";
  public static final String PRICE = "price";
  public static final String WASPRICE = "wasPrice";
  public static final String AVERAGEWEIGHT = "AverageWeight";
  public static final String PRICEPER = "pricePer";
  public static final String UNITOFMEASURE = "unitOfMeasure";
  public static final String SELLBYWEIGHT = "sellByWeight";
  public static final String AISLEID = "AisleId";
  public static final String AISLENAME = "AisleName";
  public static final String DEPARTMENTNAME = "DepartmentName";
  public static final String SHELFNAME = "ShelfName";
  public static final String RESTRICTEDVALUE = "priceRestriction";
  public static final String DISPLAYTYPE = "DisplayType";
  public static final String SALESRANK = "SalesRank";
  public static final String ID = "id";
  JsonObject elevaateJson = new JsonObject();

  public JsonElement getField(String key) {
    if (getProductAttribute(elevaateJson, key).equals("")) {
      return elevaateJson.get(key);
    }
    return new JsonParser().parse(getProductAttribute(elevaateJson, key));
  }

  public ElevaateObject(JsonObject j) {
    this.elevaateJson = j;
  }

  public static String getProductAttribute(JsonObject j, String att) {
    if (j == null)
      return "";
    if (getProductAttributes(j).size() == 0)
      return "";
    if (getProductAttributes(j).get(att) == null)
      return "";
    return getProductAttributes(j).get(att).getAsString();
  }

  public static JsonObject getProductAttributes(JsonObject j) {
    if (j.get(PRODUCTATTRIBUTES) == null)
      return new JsonObject();
    return j.get(PRODUCTATTRIBUTES).getAsJsonObject();
  }

  public JsonElement getDepartmentName() {
    return getAttrib(DEPARTMENTNAME);
  }

  public JsonElement getAttrib(String key) {
    return getProductAttributes(this.elevaateJson).get(key);
  }

}
