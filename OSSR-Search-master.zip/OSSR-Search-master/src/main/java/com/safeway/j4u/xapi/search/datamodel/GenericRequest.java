package com.safeway.j4u.xapi.search.datamodel;

import java.util.HashMap;
import java.util.Map;
import com.safeway.j4u.xapi.search.controller.params.ParamsImpl;
import com.safeway.j4u.xapi.search.datamodel.elevaate.ElevaateRequest;
import com.safeway.j4u.xapi.search.datamodel.elevaate.ElevaateResponse;
import com.safeway.j4u.xapi.search.datamodel.request.GenericDepartmentRequest;
import com.safeway.j4u.xapi.search.util.apiutil.MakeBRRequest;
import com.safeway.j4u.xapi.search.util.apiutil.MakeElevaateRequest;
import reactor.core.publisher.Flux;

public abstract class GenericRequest {

  String response;

  public GenericRequest(Map<String, String> call) {
    setCall(call);
  }

  public GenericRequest() {

  }

  private Map<String, String> call = new HashMap<>();

  public Map<String, String> getCall() {
    return call;
  }

  public void setCall(Map<String, String> req) {
    this.call = req;
  }

  // Does request for webflux
  public static Flux<GenericResponse> doRequest(Map<String, String> req) {
    GenericRequest br = new GenericDepartmentRequest(req);
    return Flux.just(br.doRequest());
  }

  // Does Elevaate
  public GenericResponse doElevaate() {
    ElevaateRequest req = new ElevaateRequest(this.call);
    ElevaateResponse resp = req.doRequest();
    GenericResponse br = new GenericResponse();
    br.setResponseAndReturn(resp.getResponse());
    return br;
  }

  // Does request and gets response
  public GenericResponse doRequest() {
    if (this.call.get(ParamsImpl.AISLE) != null)
      if (this.call.get(ParamsImpl.AISLE).equals(MakeElevaateRequest.ELEVAATEREQUEST)) {
        return doElevaate();
      }
    GenericResponse br = new GenericResponse();
    MakeBRRequest mr = new MakeBRRequest();
    br.setResponse(mr.makeBRSearchRequest(this.call));
    this.response = br.getResponse();
    return br;
  }

  public String getResponse() {
    return response;
  }

}
