package com.safeway.j4u.xapi.search.controller.params;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.safeway.j4u.xapi.search.controller.XAPIService;
import com.safeway.j4u.xapi.search.datamodel.GenericResponse;
import com.safeway.j4u.xapi.search.datamodel.brdatamodels.response.elevaate.ElevaateResponseTransform;
import com.safeway.j4u.xapi.search.datamodel.brdatamodels.response.storehierarchy.StoreHierarchy;
import com.safeway.j4u.xapi.search.datamodel.elevaate.ElevaateObject;
import com.safeway.j4u.xapi.search.util.apiutil.MakeBRRequest;

public class ParamsImpl {

  private ParamsImpl() {}

  public static final String PARAMAND = "&";
  public static final String PARAMEQUALS = "=";
  public static final String AISLE = "aisle";
  public static final String AISLES = "aisles";
  public static final String DEPARTMENT = "department";
  public static final String UID = "_br_uid_2";
  public static final String DOMAIN = "domain_key";
  public static final String REFURL = "ref_url";
  public static final String REQUESTID = "request_id";
  public static final String ROWS = "rows";
  public static final String START = "start";
  public static final String FL = "fl";
  public static final String URL = "url";
  public static final String FQ = "fq";
  public static final String SORT = "sort";
  public static final String VIEWID = "view_id";
  public static final String USERID = "user_id";
  public static final String RESPONSE = "response";
  public static final String DSSLOCATIONS = "dssLocations";
  public static final String CODE = "\"code\":";
  public static final String SEARCHTEXT = "stxt";
  public static final String CSW = "csw";
  public static final String REQUESTYPE = "request_type";
  public static final String DEFAULTREQUESTYPE = "search";
  public static final String USID = "usid";
  public static final String Q = "q";
  public static final String STOREID = "stid";
  public static final String CATEGORY = "category";
  public static final String SEARCHTYPE = "search_type";
  public static final String KEYWORD = "keyword";

  // Parses response
  public static String cleanString(List<GenericResponse> b, Map<String, String> params) {
    if (params.get(ParamMapping.STOREHIERARCHY) != null)
      if (params.get(ParamMapping.STOREHIERARCHY).equalsIgnoreCase(Boolean.TRUE.toString())) {
        return new StoreHierarchy(params).doStoreHierarchy(b);
      }
    GenericResponse result = new GenericResponse();
    GenericResponse elevaateResponse = new GenericResponse();
    GenericResponse aisleResponse = new GenericResponse();
    for (GenericResponse br : b) {
      if (br.getResponse().contains(DSSLOCATIONS)) {
        elevaateResponse = br;
      } else {
        if (br.getResponse().contains(CODE))
          continue;
        aisleResponse = br;
        result = br;
        addFeaturedFlag(br);
      }
    }
    if (params.get(ParamMapping.FEATURED) != null) {
      return ElevaateResponseTransform.doCarousel(elevaateResponse).getResponse();
    }
    if (elevaateResponse.getResponse() != null) {
      return ElevaateResponseTransform.doElevaateResponse(elevaateResponse, aisleResponse)
          .getResponse();
    }
    return doClean(result);
  }


  // Dedups and removes slashes
  public static String doClean(GenericResponse r) {
    if (r.getResponse() == null)
      return "";
    if (new JsonParser().parse(r.getResponse()).isJsonArray())
      r.setResponse(dedup(new JsonParser().parse(r.getResponse()).getAsJsonArray()).toString());
    return removeSlashes(r).getResponse();
  }

  public static GenericResponse removeSlashes(GenericResponse r) {
    r.setResponse(r.getResponse().replace("//", ""));
    return r;
  }

  public static JsonArray dedup(JsonArray input) {
    JsonArray jar = new JsonArray();
    Set<String> foundkeys = new HashSet<>();
    for (JsonElement e : input) {
      JsonObject j = e.getAsJsonObject();
      Set<String> keys = j.keySet();
      String key = "";
      for (String s : keys) {
        key = s;
        if (true)
          break;
      }
      if (foundkeys.contains(key))
        continue;
      foundkeys.add(key);
      jar.add(j);
    }
    return jar;
  }

  // Adds featured flag
  public static GenericResponse addFeaturedFlag(GenericResponse r) {
    if (!new JsonParser().parse(r.getResponse()).isJsonObject())
      return r;
    JsonObject j = new JsonParser().parse(r.getResponse()).getAsJsonObject();
    JsonObject temp = XAPIService.getResponse(j);
    if (temp == null)
      return r;
    JsonArray jar = XAPIService.getResponse(j).get(MakeBRRequest.getDocs()).getAsJsonArray();
    for (JsonElement je : jar) {
      je.getAsJsonObject().add(ElevaateObject.FEATURED,
          new JsonParser().parse(ElevaateObject.FALS));
    }
    r.setResponse(j.toString());
    return r;
  }

}
