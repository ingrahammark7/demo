package com.safeway.j4u.xapi.search.datamodel.elevaate;

import java.util.HashMap;
import java.util.Map;
import com.safeway.j4u.xapi.search.controller.params.ParamsImpl;
import com.safeway.j4u.xapi.search.util.apiutil.MakeElevaateRequest;

public class ElevaateRequest {

  public static final String SEARCHTEXT = ParamsImpl.SEARCHTEXT;
  public static final String CSW = ParamsImpl.CSW;
  Map<String, String> call = new HashMap<>();

  public ElevaateRequest(Map<String, String> call) {
    this.call = call;
  }

  public void setCall(Map<String, String> call) {
    this.call = call;
  }

  public Map<String, String> getCall() {
    return call;
  }

  public ElevaateResponse doRequest() {
    MakeElevaateRequest el = new MakeElevaateRequest(call);
    ElevaateResponse resp = new ElevaateResponse();
    resp.setResponse(el.doWork());
    return resp;
  }

}
