package com.safeway.j4u.xapi.search.controller.flux;

import java.util.List;
import java.util.Map;
import com.safeway.j4u.xapi.search.datamodel.GenericRequest;
import com.safeway.j4u.xapi.search.datamodel.GenericResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

public class FluxCall {

  private FluxCall() {}

  // Does webflux call
  public static Mono<List<GenericResponse>> doMono(List<Map<String, String>> calls) {
    return Flux.fromIterable(calls).parallel().runOn(Schedulers.parallel())
        .flatMap(req -> GenericRequest.doRequest(req)).flatMap(response -> Mono.just(response))
        .sequential().collectList();
  }

}
