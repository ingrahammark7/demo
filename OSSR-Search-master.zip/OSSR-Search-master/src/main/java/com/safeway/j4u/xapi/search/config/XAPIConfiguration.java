package com.safeway.j4u.xapi.search.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import lombok.Getter;
import lombok.Setter;

@Primary
@Configuration
@ConfigurationProperties
@PropertySource("classpath:application.properties")
@EnableConfigurationProperties(XAPIConfiguration.class)
public class XAPIConfiguration {

  @Getter
  @Setter
  @Value("${accountid}")
  private String accountid;
  @Getter
  @Setter
  @Value("${apimkeyheader}")
  public String apimkeyheader;
  @Getter
  @Setter
  @Value("${apimkey}")
  public String apimkey;
  @Getter
  @Setter
  @Value("${authkey}")
  public String authkey;
  @Getter
  @Setter
  @Value("${brenv}")
  public String brenv;
  @Getter
  @Setter
  @Value("${elevaateenv}")
  public String elevaateenv;
  @Value("${productorder}")
  @Getter
  @Setter
  public String productorder;
  @Getter
  @Setter
  @Value("${apiauthkey}")
  public String apiauthkey;
  @Getter
  @Setter
  @Value("${elevaateapimkey")
  public String elevaateapimkey;

  private static XAPIConfiguration instance;

  public XAPIConfiguration() {
    // required for spring
  }

  public static XAPIConfiguration set(XAPIConfiguration newinstance) {
    instance = newinstance;
    return instance;
  }

  public static XAPIConfiguration get() {
    if (instance == null) {
      instance = new XAPIConfiguration();
    }
    return instance;
  }


}
