package com.safeway.j4u.xapi.search.util.apiutil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.message.BasicNameValuePair;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.safeway.j4u.xapi.search.config.XAPIConfiguration;
import com.safeway.j4u.xapi.search.controller.params.ParamMapping;
import com.safeway.j4u.xapi.search.controller.params.ParamsImpl;

public class MakeBRRequest {

  public MakeBRRequest() {
    // Constructor
  }

  private static String br1 = "https://" + XAPIConfiguration.get().getBrenv()
      + ".apim.azwestus.stratus.albertsons.com/api/v1/core-qa/Search_Results";
  public static final String AISLES = ParamsImpl.AISLES;
  private static String docs = "docs";
  private static String searchtype = ParamsImpl.SEARCHTYPE;
  private static int timeout = 1000;
  private static String authkey = "auth_key";
  private static String domainkey = ParamsImpl.DOMAIN;
  private static String albertsons = "albertsons";
  private static String requestid = ParamsImpl.REQUESTID;
  private static String defaultrid = "9890441883076";
  public static final String URL = ParamsImpl.URL;
  private static String defaulturl = "www.bloomique.com";
  public static final String REFURL = ParamsImpl.REFURL;
  private static String defaultrefurl = defaulturl;
  private static String rows = ParamsImpl.ROWS;
  private static String defaultrows = "30";
  private static String start = ParamsImpl.START;
  private static String defaultstart = "0";
  private static String fl = ParamsImpl.FL;
  private static String defaultfl =
      "pid,id,upc,name,aisleId,departmentName,aisleName,shelfName,salesRank,price,basePrice,pricePer,unitOfMeasure,restrictedValue,sellByWeight,averageWeight,promoDescription,displayType,promoText,promoType";
  private static String category = ParamsImpl.CATEGORY;
  private static String accountid = "account_id";
  private static String requestype = ParamsImpl.REQUESTYPE;
  public static final String DEFAULTREQUESTYPE = ParamsImpl.DEFAULTREQUESTYPE;
  private static String clubcardnumber = ParamsImpl.USERID;
  private static String[] brparams = {ParamsImpl.SORT, ParamsImpl.VIEWID, ParamsImpl.FQ,
      ParamsImpl.UID, ParamsImpl.Q, authkey, domainkey, requestid, URL, REFURL, rows, start, fl,
      searchtype, accountid, requestype, clubcardnumber};


  public static String getDocs() {
    return docs;
  }

  public static Map<String, String> putIfNull(Map<String, String> param, String key, String value) {
    if (param.get(key) == null)
      param.put(key, value);
    return param;
  }

  public Map<String, String> buildBRParams(Map<String, String> params) {
    putIfNull(params, authkey, XAPIConfiguration.get().getAuthkey());
    putIfNull(params, domainkey, albertsons);
    putIfNull(params, requestid, defaultrid);
    putIfNull(params, URL, defaulturl);
    putIfNull(params, REFURL, defaultrefurl);
    putIfNull(params, rows, defaultrows);
    putIfNull(params, start, defaultstart);
    putIfNull(params, fl, defaultfl);
    putIfNull(params, searchtype, category);
    putIfNull(params, accountid, XAPIConfiguration.get().getAccountid());
    putIfNull(params, requestype, DEFAULTREQUESTYPE);
    return params;
  }


  public static List<NameValuePair> buildParams(Map<String, String> param, String[] paramlist) {
    List<NameValuePair> params = new ArrayList<>();
    for (Entry<String, String> s : param.entrySet()) {
      if (s.getValue() == null)
        continue;
      for (String ss : paramlist) {
        if (s.getKey().equals(ss)) {
          NameValuePair vp = new BasicNameValuePair(s.getKey(), s.getValue());
          params.add(vp);
        }
      }
    }
    return params;
  }

  public String makeBRSearchRequest(Map<String, String> params) {
    buildBRParams(params);
    Map<String, String> headers = CallHelper.buildHeader();
    String result = "";
    List<NameValuePair> nv = buildParams(params, brparams);
    URIBuilder builder = new URIBuilder();
    builder.setPath(br1);
    builder.setParameters(nv);
    String request = "";
    try {
      request = builder.build().toString();
    } catch (Exception e) {
      return "";
    }
    request = ParamMapping.doFqHack(params, request);
    result += "{\"" + AISLES + "\":"
        + APIRequest.makeAPIRequestAndGetString(request, headers, timeout) + "}";
    JsonParser parse = new JsonParser();
    JsonElement je = new JsonObject();
    try {
      je = parse.parse(result);
    } catch (Exception e) {
      // No response
    }
    result = je.toString();
    return result;
  }

}
