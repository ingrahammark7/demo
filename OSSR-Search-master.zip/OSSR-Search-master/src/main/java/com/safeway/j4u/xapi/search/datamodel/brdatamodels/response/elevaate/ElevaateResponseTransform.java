package com.safeway.j4u.xapi.search.datamodel.brdatamodels.response.elevaate;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.safeway.j4u.xapi.search.config.XAPIConfiguration;
import com.safeway.j4u.xapi.search.controller.XAPIService;
import com.safeway.j4u.xapi.search.controller.params.ParamsImpl;
import com.safeway.j4u.xapi.search.datamodel.GenericResponse;
import com.safeway.j4u.xapi.search.datamodel.brdatamodels.response.BRAisleResponse;
import com.safeway.j4u.xapi.search.datamodel.elevaate.ElevaateObject;
import com.safeway.j4u.xapi.search.util.apiutil.MakeBRRequest;

public class ElevaateResponseTransform {

  private ElevaateResponseTransform() {}

  public static final String PROMOTIONS = "promotions";
  public static final String BRPID = "pid";
  public static final String ELEVAATEPID = "productIdInFeed";
  public static final String PRODUCTORDERSEPARATOR = ",";

  // Does Elevaate response
  public static GenericResponse doElevaateResponse(GenericResponse er, GenericResponse br) {
    JsonObject jbr = new JsonParser().parse(br.getResponse()).getAsJsonObject();
    JsonArray jabr = XAPIService.getResponse(jbr).get(MakeBRRequest.getDocs()).getAsJsonArray();
    JsonObject jev = new JsonParser().parse(er.getResponse()).getAsJsonObject();
    return addElevaateProducts(jev, br, jabr, jbr);
  }

  // Does carousel
  public static GenericResponse doCarousel(GenericResponse er) {
    JsonObject jev = new JsonParser().parse(er.getResponse()).getAsJsonObject();
    JsonArray jaev = getPromotions(jev);
    JsonArray newArray = new JsonArray();
    for (JsonElement e : jaev) {
      JsonObject jo = parseElevaateJson(e.getAsJsonObject());
      newArray.add(jo);
    }
    er.setResponse(newArray.toString());
    return er;
  }

  // Adds Elevaate products
  public static GenericResponse addElevaateProducts(JsonObject jev, GenericResponse br,
      JsonArray jabr, JsonObject jbr) {
    JsonArray jaev = getPromotions(jev);
    Map<String, JsonObject> elPidMap = buildelevaatepid(jaev);
    buildBRProducts(elPidMap, jabr);
    jabr = XAPIService.getResponse(jbr).get(MakeBRRequest.getDocs()).getAsJsonArray();
    for (Entry<String, JsonObject> e : elPidMap.entrySet()) {
      String s = e.getKey();
      JsonObject j = elPidMap.get(s);
      j = parseElevaateJson(j);
      jabr.add(j);
    }
    String arr = orderElevaateProducts(jabr);
    arr = insertProducts(jbr, arr);
    br.setResponse(arr);
    return br;
  }

  // Adds products to an array
  public static String insertProducts(JsonObject jbr, String arr) {
    String arr2 = jbr.toString();
    String[] spl = arr2.split(MakeBRRequest.getDocs());
    String[] spl1 = spl[1].split(XAPIService.FACETCOUNTS);
    return spl[0] + MakeBRRequest.getDocs() + "\":" + arr + "},\"" + XAPIService.FACETCOUNTS
        + spl1[1];
  }

  // Adds element to array
  public static StringBuilder addElement(JsonElement e, StringBuilder newArray) {
    newArray.append(e.toString());
    newArray.append(",");
    return newArray;
  }

  // Builds result array
  public static StringBuilder buildNewArray(JsonArray featured, JsonArray notfeatured,
      String[] arr) {
    int i = 0;
    int j = 0;
    StringBuilder newArray = new StringBuilder();
    for (JsonElement e : notfeatured) {
      if (j > arr.length - 1)
        j = arr.length - 1;
      int val = Integer.parseInt(arr[j]);
      if (arr.length > j && i == val - 1 && featured.size() > j) {
        newArray.append(featured.get(j).toString());
        newArray.append(PRODUCTORDERSEPARATOR);
        ++j;
        ++i;
      }
      addElement(e, newArray);
      ++i;
    }
    int val = Integer.parseInt(arr[j]);
    if (val == i + 1) {
      newArray.append(featured.get(j).toString());
      newArray.append(PRODUCTORDERSEPARATOR);
    }
    return newArray;
  }

  // Orders products
  public static String orderElevaateProducts(JsonArray products) {
    String productorder = XAPIConfiguration.get().getProductorder();
    String[] arr = productorder.split(PRODUCTORDERSEPARATOR);
    JsonArray featured = new JsonArray();
    JsonArray notfeatured = new JsonArray();
    for (JsonElement e : products) {
      if (e.getAsJsonObject().get(ElevaateObject.FEATURED).getAsString().equals(ElevaateObject.TRU))
        featured.add(e);
      else
        notfeatured.add(e);
    }
    StringBuilder newArray = buildNewArray(featured, notfeatured, arr);
    return "[" + newArray.toString().substring(0, newArray.toString().length() - 1) + "]";
  }

  // Adds BR products
  public static JsonArray buildBRProducts(Map<String, JsonObject> elPidMap, JsonArray jabr) {
    for (JsonElement j : jabr) {
      boolean isfeatured = false;
      JsonObject jo = j.getAsJsonObject();
      String pid = jo.get(BRPID).getAsString();
      if (elPidMap.get(pid) != null)
        isfeatured = true;
      elPidMap.remove(pid);
      if (!isfeatured)
        jo.add(ElevaateObject.FEATURED, new JsonParser().parse(ElevaateObject.FALS));
      else
        jo.add(ElevaateObject.FEATURED, new JsonParser().parse(ElevaateObject.TRU));
    }
    return jabr;
  }

  // Gets promotions JSON
  public static JsonArray getPromotions(JsonObject jev) {
    return jev.get(ParamsImpl.DSSLOCATIONS).getAsJsonArray().get(0).getAsJsonObject()
        .get(PROMOTIONS).getAsJsonArray();
  }

  // Builds map between elevaate and br
  public static Map<String, JsonObject> buildpidmap(JsonArray barr, String pidkey) {
    HashMap<String, JsonObject> result = new HashMap<>();
    for (JsonElement b : barr) {
      JsonObject j = b.getAsJsonObject();
      String pid = j.get(pidkey).getAsString();
      result.put(pid, j);
    }
    return result;
  }

  public static Map<String, JsonObject> buildBRpid(JsonArray barr) {
    return buildpidmap(barr, BRPID);
  }

  public static Map<String, JsonObject> buildelevaatepid(JsonArray barr) {
    return buildpidmap(barr, ELEVAATEPID);
  }

  // Makes elevaate json a BR json
  public static JsonObject parseElevaateJson(JsonObject j) {
    JsonObject result = new JsonObject();
    ElevaateObject el = new ElevaateObject(j);
    JsonElement pid = el.getField(ElevaateObject.PRODUCTIDINFEED);
    JsonElement upc = el.getField(ElevaateObject.UPC);
    JsonElement name = el.getField(ElevaateObject.TITLE);
    JsonElement wasPrice = el.getField(ElevaateObject.WASPRICE);
    JsonElement averageWeight = el.getField(ElevaateObject.AVERAGEWEIGHT);
    JsonElement pricePer = el.getField(ElevaateObject.PRICEPER);
    JsonElement unitOfMeasure = el.getField(ElevaateObject.UNITOFMEASURE);
    JsonElement sellByWeight = el.getField(ElevaateObject.SELLBYWEIGHT);
    JsonElement aisleId = el.getField(ElevaateObject.AISLEID);
    JsonElement aisleName = el.getAttrib(ElevaateObject.AISLENAME);
    JsonElement departmentName = el.getDepartmentName();
    JsonElement shelfName = el.getAttrib(ElevaateObject.SHELFNAME);
    JsonElement restrictedValue = el.getField(ElevaateObject.RESTRICTEDVALUE);
    JsonElement displayType = el.getField(ElevaateObject.DISPLAYTYPE);
    JsonElement salesRank = el.getField(ElevaateObject.SALESRANK);
    JsonElement price = el.getField(ElevaateObject.PRICE);
    result.add(BRAisleResponse.PID, pid);
    result.add(BRAisleResponse.UPC, upc);
    result.add(BRAisleResponse.NAME, name);
    result.add(BRAisleResponse.BASEPRICE, wasPrice);
    result.add(BRAisleResponse.AVERAGEWEIGHT, averageWeight);
    result.add(BRAisleResponse.AVERAGEWEIGHT, averageWeight);
    result.add(BRAisleResponse.PRICEPER, pricePer);
    result.add(BRAisleResponse.UNITOFMEASURE, unitOfMeasure);
    result.add(BRAisleResponse.SELLBYWEIGHT, sellByWeight);
    result.add(BRAisleResponse.AISLEID, aisleId);
    result.add(BRAisleResponse.AISLENAME, aisleName);
    result.add(BRAisleResponse.DEPARTMENTNAME, departmentName);
    result.add(BRAisleResponse.SHELFNAME, shelfName);
    result.add(BRAisleResponse.RESTRICTEDVALUE, restrictedValue);
    result.add(BRAisleResponse.DISPLAYTYPE, displayType);
    result.add(BRAisleResponse.SALESRANK, salesRank);
    result.add(ElevaateObject.FEATURED, new JsonParser().parse(ElevaateObject.TRU));
    result.add(ElevaateObject.PRICE, price);
    result.add(ElevaateObject.ID, pid);
    return result;
  }

}
