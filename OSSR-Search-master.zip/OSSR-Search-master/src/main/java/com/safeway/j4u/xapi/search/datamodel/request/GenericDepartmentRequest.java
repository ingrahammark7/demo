package com.safeway.j4u.xapi.search.datamodel.request;

import java.util.Map;
import com.safeway.j4u.xapi.search.datamodel.GenericRequest;

public class GenericDepartmentRequest extends GenericRequest {

  public GenericDepartmentRequest(Map<String, String> req) {
    this.setCall(req);
  }

}
