package com.safeway.j4u.xapi.search.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.google.gson.JsonObject;
import com.safeway.j4u.xapi.search.controller.flux.FluxCall;
import com.safeway.j4u.xapi.search.controller.impl.RequestBuilder;
import com.safeway.j4u.xapi.search.controller.params.ParamMapping;
import com.safeway.j4u.xapi.search.datamodel.GenericResponse;
import com.safeway.j4u.xapi.search.util.apiutil.MakeBRRequest;
import com.safeway.j4u.xapi.search.util.apiutil.MakeElevaateRequest;
import reactor.core.publisher.Mono;



@Service
public class XAPIService {

  public static final String FACETCOUNTS = "facet_counts";
  public static final String FACETFIELDS = "facet_fields";
  public static final String RESPONSE = "response";

  // Main program
  public Mono<List<GenericResponse>> findById(Map<String, String> id) {
    List<Map<String, String>> calls = new ArrayList<>();
    calls = flag(id, calls, ParamMapping.BR);
    Map<String, String> newmap = RequestBuilder.buildmap(id, MakeElevaateRequest.ELEVAATEREQUEST);
    calls = flag(newmap, calls, ParamMapping.EL);
    return FluxCall.doMono(calls);
  }

  // Handle null pointer in request params
  public List<Map<String, String>> flag(Map<String, String> call, List<Map<String, String>> calls,
      String flag) {
    if (call.get(flag) == null) {
      calls.add(call);
      return calls;
    }
    if (call.get(flag).equalsIgnoreCase(Boolean.TRUE.toString())) {
      calls.add(call);
      return calls;
    }
    return calls;
  }

  // Get response object out of JSON
  public static JsonObject getResponse(JsonObject jo) {
    try {
      return jo.get(MakeBRRequest.AISLES).getAsJsonObject().get(RESPONSE).getAsJsonObject();
    } catch (Exception e) {
      return null;
    }
  }

}
