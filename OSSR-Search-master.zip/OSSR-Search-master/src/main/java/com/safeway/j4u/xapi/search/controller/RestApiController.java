package com.safeway.j4u.xapi.search.controller;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.safeway.j4u.xapi.search.config.XAPIConfiguration;
import com.safeway.j4u.xapi.search.controller.params.ParamMapping;
import com.safeway.j4u.xapi.search.controller.params.ParamsImpl;
import com.safeway.j4u.xapi.search.datamodel.GenericResponse;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/ossr-search")
@Service
public class RestApiController {


  @Autowired
  XAPIService xapiService = new XAPIService();

  @Autowired
  XAPIConfiguration config;

  @GetMapping(value = "/productgrid/")
  public Mono<ResponseEntity<String>> doCat(@RequestParam Map<String, String> params) {
    return doController(params);
  }

  @GetMapping("/carouselresults/")
  public Mono<ResponseEntity<String>> doCar(@RequestParam Map<String, String> params) {
    params.put(ParamMapping.CAROUSEL, Boolean.TRUE.toString());
    return doController(params);
  }

  @GetMapping("/storehierarchy/")
  public Mono<ResponseEntity<String>> doStore(@RequestParam Map<String, String> params) {
    params.put(ParamMapping.STOREHIERARCHY, Boolean.TRUE.toString());
    return doController(params);
  }

  public Mono<ResponseEntity<String>> doController(Map<String, String> params) {
    XAPIConfiguration.set(config);
    params = ParamMapping.mapParams(params);
    if (params.get(ParamMapping.EXCEPTION) != null)
      return Mono.just(doResponse(params.get(ParamMapping.EXCEPTION)));
    return doLogic(params);
  }

  public Mono<ResponseEntity<String>> doLogic(Map<String, String> params) {
    Mono<List<GenericResponse>> xAPIResult = xapiService.findById(params);
    return xAPIResult.map(e -> doResponse(ParamsImpl.cleanString(e, params)));
  }

  public ResponseEntity<String> doResponse(String resp) {
    HttpHeaders resph = new HttpHeaders();
    resph.set("Content-Type", "application/json");
    return ResponseEntity.ok().headers(resph).body(resp);
  }

}
