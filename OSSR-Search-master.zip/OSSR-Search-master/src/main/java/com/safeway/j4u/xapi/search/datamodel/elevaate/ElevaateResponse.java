package com.safeway.j4u.xapi.search.datamodel.elevaate;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ElevaateResponse {

  private String response;


  public ElevaateResponse setResponse(String resp) {
    this.response = resp;
    return this;
  }

}
