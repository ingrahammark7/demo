package com.safeway.j4u.xapi.search.util.apiutil;



import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Map.Entry;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.util.encoders.Base64;
import com.safeway.j4u.xapi.search.config.XAPIConfiguration;

public class APIRequest {

  private APIRequest() {}

  public static String makeAPIRequestAndGetString(String endpoint, Map<String, String> headers,
      int timeout) {
    try {
      HttpURLConnection conn = doConnection(endpoint, headers, timeout);
      BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
      StringBuilder response = doResponse(br);
      return response.toString();
    } catch (Exception e) {
      return e.getMessage();
    }
  }

  private static StringBuilder doResponse(BufferedReader br) throws Exception {
    String inputLine = "";
    StringBuilder response = new StringBuilder();
    while ((inputLine = br.readLine()) != null) {
      response.append(inputLine);
    }
    br.close();
    return response;
  }

  private static String getDate() {
    String timeformat = "EEE, d MMM yyyy HH:mm:ss Z";
    DateTimeFormatter dt = DateTimeFormatter.ofPattern(timeformat);
    ZonedDateTime dd = ZonedDateTime.now();
    return dd.format(dt).toString();
  }

  private static Map<String, String> doElHeaders(Map<String, String> headers, String endpoint) {
    String str = "GET" + endpoint;
    MakeElevaateRequest.setOriginalEndpoint(null);
    str += getDate();
    str = encrypt(XAPIConfiguration.get().getApiauthkey(), str);
    headers.put("X-Elevaate-Signature", str);
    headers.put("Date", getDate());
    headers.put("Ocp-Apim-Subscription-Key", XAPIConfiguration.get().elevaateapimkey);
    return headers;
  }

  private static String generateHmac(String keyString, String msg) throws Exception {
    String digest = null;
    String algo = "HmacSHA1";
    try {
      SecretKeySpec key = new SecretKeySpec((keyString).getBytes("UTF-8"), algo);
      Mac mac = Mac.getInstance(algo);
      mac.init(key);
      byte[] bytes = mac.doFinal(msg.getBytes("ASCII"));
      StringBuffer hash = new StringBuffer();
      for (int i = 0; i < bytes.length; i++) {
        String hex = Integer.toHexString(0xFF & bytes[i]);
        if (hex.length() == 1) {
          hash.append('0');
        }
        hash.append(hex);
      }
      digest = hash.toString();
    } catch (UnsupportedEncodingException e) {
    } catch (Exception e) {
    }
    return digest;
  }



  private static String encrypt(String keyString, String message) {
    String result = null;
    try {
      result = generateHmac(keyString, message);
      result = Base64.toBase64String(result.getBytes());
      return result;
    } catch (Exception e) {
      // Invalid
    }
    return null;
  }

  private static HttpURLConnection doConnection(String endpoint, Map<String, String> headers,
      int timeout) {
    if (endpoint.contains("renderPage")) {
      doElHeaders(headers, MakeElevaateRequest.getOriginalEndpoint());
    }
    try {
      endpoint = endpoint.replace("%2520", "%20");
      endpoint = endpoint.replace("%5B", "[");
      endpoint = endpoint.replace("%5D", "]");
      URL url = new URL(endpoint);
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setConnectTimeout(timeout);
      if (headers != null)
        for (Entry<String, String> se : headers.entrySet()) {
          String s = se.getKey();
          String h = headers.get(s);
          conn.setRequestProperty(s, h);
        }
      conn.setRequestMethod("GET");
      return conn;
    } catch (Exception e) {
      return null;
    }
  }

}
