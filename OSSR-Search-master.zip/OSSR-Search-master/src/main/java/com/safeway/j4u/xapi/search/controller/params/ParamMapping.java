package com.safeway.j4u.xapi.search.controller.params;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.commons.logging.Log;
import com.safeway.j4u.xapi.search.util.apiutil.MakeBRRequest;

public class ParamMapping {

  private ParamMapping() {}

  private static String price = "price";
  private static String featuredsessionid = "featuredsessionid";
  private static String clientscreenwidth = "clientscreenwidth";
  public static final String PAGENAME = "pagename";
  private static String requestid = "requestid";
  private static String pageurl = "pageurl";
  private static String storeid = "storeid";
  private static String searchid = "_search_id_2";
  public static final String FEATURED = "featured";
  public static final String AISLES = "+aisles+";
  public static final String SEARCH = "+search-results";
  public static final String STOREHIERARCHY = "storehierarchy";
  private static final String CSW = ParamsImpl.CSW;
  private static final String URL = ParamsImpl.URL;
  private static final String SEARCHID2 = ParamsImpl.UID;
  private static final String USID = ParamsImpl.USID;
  private static final String REFURL = ParamsImpl.REFURL;
  private static final String VIEWID = ParamsImpl.VIEWID;
  public static final String BR = "br";
  public static final String EL = "el";
  public static final String CAROUSEL = "carousel";
  public static final String CATEGORYID = "categoryid";
  public static final String BANNERURL = "bannerurl";
  private static final String ROWS = ParamsImpl.ROWS;
  private static final String START = ParamsImpl.START;
  private static final String[] required = {PAGENAME, BANNERURL, ROWS, START, pageurl, storeid};
  private static final String[] gridrequired = {searchid, requestid};
  private static final String[] storehierarchyrequired = gridrequired;
  public static final String EXCEPTION = "EXCEPTION";
  private static final String Q = ParamsImpl.Q;
  private static final String CLUBCARDNUMBER = "userid";

  static Log log;

  public static Map<String, String> makeLowerCase(Map<String, String> params) {
    Map<String, String> param2 = new HashMap<>();
    for (Entry<String, String> s : params.entrySet()) {
      param2.put(s.getKey().toLowerCase(), s.getValue());
    }
    return param2;
  }

  // Handle null pointer in params
  public static Map<String, String> flag(Map<String, String> params, String flag, String newflag) {
    params.put(newflag, Boolean.TRUE.toString());
    if (params.get(flag) != null) {
      if (params.get(flag).equalsIgnoreCase(Boolean.FALSE.toString()))
        params.put(newflag, Boolean.FALSE.toString());
    }
    return params;
  }

  // Validate results
  public static boolean validate(Map<String, String> params, String[] validate) {
    Set<String> keys = params.keySet();
    Set<String> compare = new HashSet<>();
    for (String s : validate) {
      compare.add(s.toLowerCase());
    }
    if (keys.containsAll(compare))
      return true;
    params.put(EXCEPTION, "Invalid params: " + keys + ". Was looking for : " + compare);
    return false;
  }

  // Validate results without list of validation items
  public static boolean validate(Map<String, String> params) {
    validate(params, required);
    if (params.get(STOREHIERARCHY) != null)
      validate(params, storehierarchyrequired);
    else if (params.get(CAROUSEL) == null)
      validate(params, gridrequired);
    if (params.get(EXCEPTION) == null)
      return true;
    return false;
  }

  private static Map<String, String> fillNull(String[] puts, Map<String, String> params) {
    for (String s : puts) {
      if (params.get(s) == null)
        params.put(s, "");
    }
    return params;
  }

  public static String doFqHack(Map<String, String> params, String url) {
    if (params.get(ParamsImpl.FQ) == null)
      return url;
    String fq = params.get(ParamsImpl.FQ);
    String[] fqs = fq.split("fq=");
    if (fqs.length < 2)
      return url;
    int x = url.indexOf("&fq=");
    String ss = url.substring(x + 1);
    int y = 0;
    if (ss.contains("&")) {
      y = ss.indexOf('&');
    } else {
      y = url.length() - x;
    }
    url = url.substring(0, x) + url.substring(x + y, url.length());
    StringBuilder sb = new StringBuilder();
    sb.append(url);
    for (int i = 0; i < fqs.length; ++i) {
      String s = fqs[i];
      try {
        sb.append("&fq=" + URLEncoder.encode(s, "UTF8"));
      } catch (Exception e) {
        return e.getMessage();
      }
    }
    return sb.toString();
  }

  // Map parameters
  public static Map<String, String> mapParams(Map<String, String> params) {
    params = makeLowerCase(params);
    if (!validate(params))
      return params;
    flag(params, FEATURED, EL);
    String[] arr = {ParamsImpl.FQ};
    fillNull(arr, params);
    params.put(BR, Boolean.TRUE.toString());
    if (params.get(ParamsImpl.FQ).contains(price) || params.get(ParamsImpl.SORT) != null)
      params.put(EL, Boolean.FALSE.toString());
    else
      params.put(EL, Boolean.TRUE.toString());
    if (params.get(STOREHIERARCHY) != null) {
      params = MakeBRRequest.putIfNull(params, EL, Boolean.FALSE.toString());
    }
    if (isSearch(params))
      params.put(ParamsImpl.SEARCHTYPE, ParamsImpl.KEYWORD);
    else
      params.put(ParamsImpl.SEARCHTYPE, ParamsImpl.CATEGORY);
    params = MakeBRRequest.putIfNull(params, CSW, params.get(clientscreenwidth));
    params = MakeBRRequest.putIfNull(params, URL, params.get(BANNERURL));
    params = MakeBRRequest.putIfNull(params, SEARCHID2, params.get(searchid));
    params = MakeBRRequest.putIfNull(params, USID, params.get(featuredsessionid));
    params = MakeBRRequest.putIfNull(params, REFURL, params.get(pageurl));
    params = MakeBRRequest.putIfNull(params, VIEWID, params.get(storeid));
    params = MakeBRRequest.putIfNull(params, requestid, params.get(requestid));
    params = MakeBRRequest.putIfNull(params, Q, params.get(CATEGORYID));
    params = MakeBRRequest.putIfNull(params, ParamsImpl.USERID, params.get(CLUBCARDNUMBER));
    return params;
  }

  // Whether the request is keyword
  public static boolean isSearch(Map<String, String> params) {
    if (params.get(PAGENAME) == null)
      return false;
    if (params.get(PAGENAME).contains(MakeBRRequest.DEFAULTREQUESTYPE))
      return true;
    return false;
  }

}
