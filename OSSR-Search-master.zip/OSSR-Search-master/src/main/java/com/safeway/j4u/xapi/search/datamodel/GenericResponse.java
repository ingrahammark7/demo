package com.safeway.j4u.xapi.search.datamodel;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GenericResponse {

  private String response;
  private String request;

  public GenericResponse setResponseAndReturn(String r) {
    this.response = r;
    return this;
  }

}
