package com.safeway.j4u.xapi.search.datamodel.brdatamodels.response.storehierarchy;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.safeway.j4u.xapi.search.controller.XAPIService;
import com.safeway.j4u.xapi.search.controller.params.ParamsImpl;
import com.safeway.j4u.xapi.search.datamodel.GenericResponse;
import com.safeway.j4u.xapi.search.util.apiutil.MakeBRRequest;

public class StoreHierarchy {

  private static String storeid = "storeId";
  private static String bannerid = "bannerId";
  private static String divisionid = "divisionId";
  private static String aisleid = "aisleId";
  private static String shelfid = "shelfId";
  private static String rog = "rog";
  private static String departments = "departments";
  private static String departmentid = "departmentId";
  private static String departmentname = "departmentName";
  private static String deplevelproductcnt = "deptLevelProductCnt";
  private static String departmentimageuri = "departmentImageUri";
  private static String departmentnameid = "departmentname_id";
  private static String aislelevelproductcnt = "aisleLevelProductCnt";
  private static String aisleimageuri = "aisleImageUri";
  private static String shelflevelproductcnt = "shelfLevelProductCnt";
  private static String shelfimageuri = "shelfImageUri";
  private static String facetcounts = XAPIService.FACETCOUNTS;
  private static String facetfields = XAPIService.FACETFIELDS;
  private static String aislename = "aisleName";
  private static String namefield = "name";
  private static String count = "count";
  private static String separator = "\\|";
  private static String underscore = "_";
  private static String shelvesstring = "shelves";
  private static String aislestring = "aisles";
  private static String shelfname = "shelfName";

  Map<String, String> params = new HashMap<>();
  JsonObject j = new JsonObject();
  Log l = LogFactory.getLog("log");

  public StoreHierarchy(Map<String, String> params) {
    this.params = params;
  }

  public GenericResponse getBRResponse(List<GenericResponse> b) {
    for (GenericResponse g : b) {
      if (g.getResponse().contains(MakeBRRequest.AISLES)
          && !g.getResponse().contains(ParamsImpl.DSSLOCATIONS))
        return g;
    }
    return null;
  }

  public String doStoreHierarchy(List<GenericResponse> b) {
    GenericResponse br = getBRResponse(b);
    JsonObject jo = new JsonParser().parse(br.getResponse()).getAsJsonObject()
        .get(MakeBRRequest.AISLES).getAsJsonObject().get(facetcounts).getAsJsonObject()
        .get(facetfields).getAsJsonObject();
    JsonArray depts = jo.get(departmentnameid).getAsJsonArray();
    JsonArray aisles = jo.get(aislename).getAsJsonArray();
    JsonArray shelves = jo.get(shelfname).getAsJsonArray();
    addIfNotNull(storeid, params.get(ParamsImpl.VIEWID));
    addIfNotNull(bannerid);
    addIfNotNull(rog);
    addIfNotNull(divisionid);
    Map<String, Integer> deptmap = buildDepartmentMap(depts);
    JsonArray deptresult = doDept(depts, aisles, deptmap, shelves);
    j.add(departments, deptresult);
    checkForException(deptresult, aisles, shelves);
    return j.toString();
  }

  private Map<String, Integer> buildDepartmentMap(JsonArray depts) {
    Map<String, Integer> result = new HashMap<>();
    for (JsonElement e : depts) {
      JsonObject jj = e.getAsJsonObject();
      result.put(jj.get(namefield).getAsString(), Integer
          .parseInt(jj.get(namefield).getAsString().split(separator)[1].split(underscore)[1]));
    }
    return result;
  }

  private void findValidAislesAndShelves(JsonArray aisles, JsonArray shelves, JsonArray deptmap) {
    Set<Integer> depts = new HashSet<>();
    for (JsonElement e : deptmap) {
      depts.add(e.getAsJsonObject().get(departmentid).getAsInt());
    }
    Set<Integer> aisleids = doCheck(aisles, depts, "Missing aisles for department ");
    doCheck(shelves, aisleids, "Missing shelves for aisles ");
  }

  // Checks if result is valid
  Set<Integer> doCheck(JsonArray aisles, Set<Integer> depts, String message) {
    Set<Integer> aisleidset = new HashSet<>();
    for (JsonElement e : aisles) {
      JsonObject jj = e.getAsJsonObject();
      int dept = Integer
          .parseInt(jj.get(namefield).getAsString().split(separator)[1].split(underscore)[0]);
      if (!depts.contains(dept))
        l.error(new Exception(message + jj.get(namefield).getAsString()));
      aisleidset.add(dept);
    }
    return aisleidset;
  }

  // Checks if result is valid and logs error
  private void checkForException(JsonArray deptmap, JsonArray aisles, JsonArray shelves) {
    findValidAislesAndShelves(aisles, shelves, deptmap);
    for (JsonElement e : deptmap) {
      JsonArray arr = e.getAsJsonObject().get(aislestring).getAsJsonArray();
      if (arr.size() == 0)
        l.error(
            new Exception("Missing aisles for department " + e.getAsJsonObject().get(namefield)));
      for (JsonElement enn : arr) {
        JsonArray ar = enn.getAsJsonObject().get(shelvesstring).getAsJsonArray();
        if (ar.size() == 0)
          l.error(
              new Exception("Missing shelves for aisle " + enn.getAsJsonObject().get(namefield)));
      }
    }
  }

  private JsonElement getName(JsonElement e) {
    return new JsonPrimitive(e.toString().split(separator)[0].substring(1));
  }

  // Builds aisle map
  private Map<String, JsonArray> buildAisleMap(Map<String, Integer> deptmap, JsonArray aisles,
      JsonArray shelves) {
    Map<String, JsonArray> result = new HashMap<>();
    for (Entry<String, Integer> entry : deptmap.entrySet()) {
      int ent = entry.getValue();
      JsonArray ja = new JsonArray();
      for (JsonElement e : aisles) {
        JsonObject jj = e.getAsJsonObject();
        String hierarchy = jj.get(namefield).getAsString().split(separator)[1];
        int dept = Integer.parseInt(hierarchy.split(underscore)[1]);
        String aisle = hierarchy.split(underscore)[2];
        if (dept == ent) {
          JsonObject jo = new JsonObject();
          jo.add(aisleid, new JsonParser().parse(aisle));
          jo.add(aislename, getName(jj.get(namefield)));
          jo.add(aislelevelproductcnt, jj.get(count));
          jo.add(aisleimageuri, new JsonParser().parse(""));
          jo.add(shelvesstring, buildShelfArray(shelves, Integer.valueOf(aisle), dept));
          ja.add(jo);
        }
      }
      result.put(entry.getKey(), ja);
    }
    return result;
  }

  private JsonArray buildShelfArray(JsonArray shelves, int aisle, int department) {
    JsonArray result = new JsonArray();
    for (JsonElement e : shelves) {
      JsonObject jj = e.getAsJsonObject();
      String[] hierarchy = jj.get(namefield).getAsString().split(separator)[1].split(underscore);
      String aisleidno = hierarchy[2];
      String deptno = hierarchy[1];
      if (Integer.valueOf(aisleidno) != aisle || Integer.valueOf(deptno) != department)
        continue;
      JsonObject jo = new JsonObject();
      jo.add(shelfid, new JsonParser().parse(aisleidno));
      jo.add(shelfname, getName(jj.get(namefield)));
      jo.add(shelflevelproductcnt, jj.get(count));
      jo.add(shelfimageuri, new JsonParser().parse(""));
      result.add(jo);
    }
    return result;
  }

  private JsonArray doDept(JsonArray depts, JsonArray aisles, Map<String, Integer> deptmap,
      JsonArray shelves) {
    JsonArray result = new JsonArray();
    Map<String, JsonArray> aislemap = buildAisleMap(deptmap, aisles, shelves);
    for (JsonElement e : depts) {
      JsonObject je = e.getAsJsonObject();
      JsonObject jj = new JsonObject();
      jj.add(departmentid,
          new JsonParser().parse(String.valueOf(deptmap.get(je.get(namefield).getAsString()))));
      jj.add(departmentname, je.get(namefield));
      jj.add(deplevelproductcnt, je.get(count));
      jj.add(departmentimageuri, new JsonParser().parse(""));
      JsonArray aisleslist = aislemap.get(je.get(namefield).getAsString());
      jj.add(aislestring, aisleslist);
      result.add(jj);
    }
    return result;
  }

  private JsonObject addIfNotNull(String key) {
    return addIfNotNull(key, params.get(key));
  }

  private JsonObject addIfNotNull(String key, String value) {
    if (value == null)
      value = "";
    j.add(key, new JsonParser().parse(value));
    return j;
  }

}
