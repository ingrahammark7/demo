package com.safeway.j4u.xapi.search.util.apiutil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;
import com.google.gson.JsonParser;
import com.safeway.j4u.xapi.search.config.XAPIConfiguration;
import com.safeway.j4u.xapi.search.controller.params.ParamMapping;
import com.safeway.j4u.xapi.search.controller.params.ParamsImpl;
import com.safeway.j4u.xapi.search.datamodel.brdatamodels.response.elevaate.ElevaateResponseTransform;
import com.safeway.j4u.xapi.search.datamodel.elevaate.ElevaateRequest;

public class MakeElevaateRequest {

  Map<String, String> req = new HashMap<>();
  static String envurl = getMinusEnv();
  String pidenv = getPidEnv();
  String end = "https://dev1.apim.azwestus.stratus.albertsons.com/render/dev/api/v2/public/api/"
      + envurl + "albertsons.com/renderPage.json";
  public static String end2 = null;
  public static final String PIDKEY = "pid";
  public static final String ELEVAATEREQUEST = "ELEVAATE";
  public static final String REPLACEPLUS = "%2B";
  public static final String FL = "fl";
  public static final String FQ = "fq";
  private static final String STOREID = ParamsImpl.STOREID;
  public static final String MXRD = "mxrd";
  public static final String DEFAULTMXRD = "middle|3";
  public static final String USID = ParamsImpl.USID;
  private static int timeout = 400;
  private static String[] elparams = {FL, MXRD, ElevaateRequest.SEARCHTEXT,
      ElevaateResponseTransform.BRPID, ElevaateRequest.CSW, USID, STOREID};

  public MakeElevaateRequest(Map<String, String> call) {
    this.req = call;
  }

  public static String setOriginalEndpoint(String newendpoint) {
    end2 = newendpoint;
    return end2;
  }

  public static String getOriginalEndpoint() {
    if (end2 == null) {
      end2 = "https://" + getEnv() + "-tag.elevaate.io/portal/public/api/" + envurl
          + "albertsons.com/renderPage.json";
    }
    return end2;
  }

  public static Map<String, String> buildElParams(Map<String, String> params) {
    if (ParamMapping.isSearch(params)) {
      params.put(MakeElevaateRequest.PIDKEY, MakeElevaateRequest.getEnv() + ParamMapping.SEARCH);
    } else {
      if (params.get(ParamMapping.PAGENAME).contains(ParamsImpl.AISLE))
        params.put(MakeElevaateRequest.PIDKEY,
            MakeElevaateRequest.getEnv() + ParamMapping.AISLES + params.get(ParamsImpl.Q));
      else
        params.put(MakeElevaateRequest.PIDKEY,
            MakeElevaateRequest.getEnv() + params.get(ParamMapping.PAGENAME));
    }
    MakeBRRequest.putIfNull(params, STOREID, params.get(ParamsImpl.VIEWID));
    MakeBRRequest.putIfNull(params, MXRD, DEFAULTMXRD);
    return params;
  }

  public String doWork() {
    buildElParams(req);
    if (ParamMapping.isSearch(req)) {
      req.put(ElevaateRequest.SEARCHTEXT, req.get(ParamsImpl.Q));
    }
    Map<String, String> header = CallHelper.buildHeader();
    List<NameValuePair> nv = MakeBRRequest.buildParams(req, elparams);
    URIBuilder builder = new URIBuilder();
    builder.setPath(end);
    builder.setParameters(nv);
    URIBuilder originalEndpointBuilder = new URIBuilder();
    originalEndpointBuilder.setPath(getOriginalEndpoint());
    originalEndpointBuilder.setParameters(nv);
    try {
      setOriginalEndpoint(originalEndpointBuilder.build().toString());
    } catch (Exception e) {
      return "";
    }
    try {
      end = builder.build().toString();
    } catch (Exception e) {
      return "";
    }
    String result = APIRequest.makeAPIRequestAndGetString(end, header, timeout);
    return new JsonParser().parse(result).toString();
  }

  public static String getEnv() {
    String env = XAPIConfiguration.get().getElevaateenv();
    if (env == null)
      return "";
    else
      return env;
  }

  public String getPlusEnv() {
    return getCharEnd("+");
  }

  public static String getMinusEnv() {
    return getCharEnd("-");
  }

  public String getPidEnv() {
    return getCharEnd(REPLACEPLUS);
  }

  public static String getCharEnd(String character) {
    if (getEnv().equals(""))
      return "";
    else
      return getEnv() + character;
  }

}
