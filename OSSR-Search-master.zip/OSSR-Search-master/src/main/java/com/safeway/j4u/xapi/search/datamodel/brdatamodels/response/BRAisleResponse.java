package com.safeway.j4u.xapi.search.datamodel.brdatamodels.response;

import com.safeway.j4u.xapi.search.datamodel.GenericResponse;

public class BRAisleResponse extends GenericResponse {
  public static final String PID = "pid";
  public static final String UPC = "upc";
  public static final String NAME = "name";
  public static final String PRICE = "price";
  public static final String BASEPRICE = "basePrice";
  public static final String AVERAGEWEIGHT = "averageWeight";
  public static final String PRICEPER = "pricePer";
  public static final String UNITOFMEASURE = "unitOfMeasure";
  public static final String SELLBYWEIGHT = "sellByWeight";
  public static final String AISLEID = "aisleId";
  public static final String AISLENAME = "aisleName";
  public static final String DEPARTMENTNAME = "departmentName";
  public static final String SHELFNAME = "shelfName";
  public static final String RESTRICTEDVALUE = "restrictedValue";
  public static final String DISPLAYTYPE = "displayType";
  public static final String SALESRANK = "salesRank";

}
