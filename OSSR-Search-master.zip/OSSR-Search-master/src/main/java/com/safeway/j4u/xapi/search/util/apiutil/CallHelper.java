package com.safeway.j4u.xapi.search.util.apiutil;

import java.util.HashMap;
import java.util.Map;
import com.safeway.j4u.xapi.search.config.XAPIConfiguration;

public class CallHelper {

  private CallHelper() {}

  public static Map<String, String> buildHeader() {
    HashMap<String, String> result = new HashMap<>();
    String keyname = XAPIConfiguration.get().getApimkeyheader();
    String keyvalue = XAPIConfiguration.get().getApimkey();
    result.put(keyname, keyvalue);
    return result;

  }

}
