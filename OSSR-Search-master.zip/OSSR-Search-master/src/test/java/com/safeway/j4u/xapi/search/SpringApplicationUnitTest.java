package com.safeway.j4u.xapi.search;

import static org.junit.jupiter.api.Assertions.assertTrue;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;
import com.safeway.j4u.xapi.search.config.XAPIConfiguration;
import com.safeway.j4u.xapi.search.controller.RestApiController;
import com.safeway.j4u.xapi.search.controller.params.ParamsImpl;
import com.safeway.j4u.xapi.search.datamodel.brdatamodels.response.BRAisleResponse;

public class SpringApplicationUnitTest {

  @Test
  public void doTest() throws Exception {
    if (XAPIConfiguration.get().productorder == null) {
      // Cannot do test if environment not set
      return;
    }
    if (XAPIConfiguration.get().getAccountid().equals("6195")) {
      return;
    }
    Map<String, String> params = new HashMap<String, String>();
    params.put(ParamsImpl.VIEWID, "1502");
    params.put("_br_uid_2", "test");
    params.put("pid", "%2Bproduct-details%2B1_5_4_2");
    params.put("csw", "1000");
    params.put("q", "1_1_1");
    doL3Test(doAPI(params));
    params.put("pageName", "search");
    doL3Test(doAPI(params));
    params.put("featured", "true");
    params.put("q", "soda");
    doL3Test(doAPI(params));
    params.put("storehierachy", "true");
    doL3Test(doAPI(params));
  }

  public static void doL3Test(String response) {
    assertTrue(response.contains(BRAisleResponse.AISLENAME));
    assertTrue(response.contains(BRAisleResponse.SHELFNAME));
    assertTrue(response.contains(BRAisleResponse.DEPARTMENTNAME));
    assertTrue(response.contains(BRAisleResponse.AVERAGEWEIGHT));
    assertTrue(response.contains(BRAisleResponse.DISPLAYTYPE));
    assertTrue(response.contains(BRAisleResponse.PRICE));
    assertTrue(response.contains(BRAisleResponse.PRICEPER));
    assertTrue(response.contains(BRAisleResponse.SALESRANK));
    assertTrue(response.contains(BRAisleResponse.SELLBYWEIGHT));
  }

  public static String doAPI(Map<String, String> params) {
    return new RestApiController().doController(params).block().getBody();
  }


}
