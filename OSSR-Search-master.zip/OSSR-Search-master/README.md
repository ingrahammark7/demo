# OSSR-Search

### Documentation

Please read the documentation here:

https://confluence.safeway.com/display/SEAR/Search+xAPI

Configuration:

https://confluence.safeway.com/display/SEAR/Search+xAPI+Deployment

### Build
Execute the following command from the parent directory to build the jar file:</br>
```
mvn package
```
Make sure the above deployment instructions are followed. 

### Running tests
```
mvn clean test or mvn clean package will run all the unit tests (*UnitTest.java)
```
## Info and Health Check Endpoints

**```Actuator:```** ```https:/ossr-search.dev.pcf.azwestus.stratus.albertsons.com/actuator```</br>
**```Info:```**  ```https://ossr-search.dev.pcf.azwestus.stratus.albertsons.com/actuator/info```</br>
**```Mappings:```**  ```https://ossr-search.dev.pcf.azwestus.stratus.albertsons.com/actuator/mappings```</br>
**```General Health Check:```** ```https://ossr-search.dev.pcf.azwestus.stratus.albertsons.com/actuator/health```</br>

## Swagger documentation/Interactive client

**```Note:```** ```use environment specific dev/qa/staging host from below url:```</br>
**```Swagger Doc```** ```https://ossr-search.dev.pcf.azwestus.stratus.albertsons.com/v2/api-docs``` 

## CI/CD
``` (for any access please work with devops team)```

**```Jenkins:	```** ```https://jenkinsserver.safeway.com/job/J4U_Nimbus/job/ossr-search/```</br>
**```Sonar:	```** ```http://sonar.apps.np.stratus.albertsons.com/dashboard?id=ossr-search```</br>
**```PCF non-prod:	```**	```https://login.system.np.stratus.albertsons.com/``` </br>

